<?php

namespace Stripe\Error;

class Idempotency extends Base
{
}
